//
//  ProfileRouterProtocol.swift
//  LearnEnglish
//
//  Created by Марк Шнейдерман on 15.07.2021.
//

import Foundation

protocol ProfileRouterProtocol {
    func showAboutUsVC()
    func goBack()
}
