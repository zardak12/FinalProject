//
//  Lesson+CoreDataClass.swift
//  LearnEnglish
//
//  Created by Марк Шнейдерман on 30.06.2021.
//
//

import Foundation
import CoreData

@objc(Lesson)
public class Lesson: NSManagedObject {

}
